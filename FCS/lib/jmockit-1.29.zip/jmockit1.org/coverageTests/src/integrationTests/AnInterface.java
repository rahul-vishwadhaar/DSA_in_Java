package integrationTests;

public interface AnInterface
{
   void doSomething(String s, boolean b);
   int returnValue();
}
